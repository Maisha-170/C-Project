﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsAppProject
{
    public partial class Manager : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        public Manager()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateGridView();
        }

        private void Manager_Load(object sender, EventArgs e)
        {

        }

        private void txtNameE_TextChanged(object sender, EventArgs e)
        {

        }

        public void PopulateGridView(string sql = "select * from TManageE ;")
        {
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dgvMain.AutoGenerateColumns = false;
            this.dgvMain.DataSource = this.Ds.Tables[0];
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string sql = "select * from TManageE where id ='" + this.txtidE.Text + "';";
            this.Ds = this.Da.ExecuteQuery(sql);

            if (this.Ds.Tables[0].Rows.Count == 1)
            {
                sql = @"update TManageE
                set name = '" + this.txtNameE.Text + @"',
                password = " + this.txtPE.Text + @",
                salary = " + this.txtSalaryE.Text + @",
                bloodgroup = '" + this.txtBloodE.Text + @"',
                designation = '" + this.txtDes.Text + @"',
                joindate = '" + this.dtpE.Text + @"'
                where id = '" + this.txtidE.Text + "';";

                try
                {
                    this.Da.ExecuteUpdateQuery(sql);
                    MessageBox.Show("Upgradation Done");
                    this.PopulateGridView();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("Error: " + exc.Message);
                }
            }
            else
            {
                sql = @"insert into TManageE
                values ('" + this.txtNameE.Text + "', '" + this.txtPE.Text + "', '" + this.txtSalaryE.Text + "',' " + this.txtBloodE.Text + "', '" + this.txtDes.Text + "','" + this.dtpE.Text + "');";
                try
                {
                    this.Da.ExecuteUpdateQuery(sql);
                    DeelegateCls d = new DeelegateCls();
                    d.showmsg();
                    this.PopulateGridView();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("Error: " + exc.Message);
                }
            }
        }
            
         

        private void dgvMain_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtidE.Text = this.dgvMain.CurrentRow.Cells["id"].Value.ToString();
            this.txtNameE.Text = this.dgvMain.CurrentRow.Cells["name"].Value.ToString();
            this.txtPE.Text = this.dgvMain.CurrentRow.Cells["password"].Value.ToString();
            this.txtSalaryE.Text = this.dgvMain.CurrentRow.Cells["salary"].Value.ToString();
            this.txtBloodE.Text = this.dgvMain.CurrentRow.Cells["bloodgroup"].Value.ToString();
            this.txtDes.Text = this.dgvMain.CurrentRow.Cells["designation"].Value.ToString();
            this.dtpE.Text = this.dgvMain.CurrentRow.Cells["joindate"].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string id = this.dgvMain.CurrentRow.Cells["id"].Value.ToString();
            string designation = this.dgvMain.CurrentRow.Cells["designation"].Value.ToString();


            string sql = "delete from TManageE where designation='"+ designation +"' and id = '" + id + "' ;";
            try
            {
                this.Da.ExecuteUpdateQuery(sql);
                MessageBox.Show("Deletion Done.");
                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: " + exc.Message);
            }

        }

        

        


        private void txtAutoSearchE_TextChanged(object sender, EventArgs e)
        {
            string sql = "select * from TManageE where name like '" + this.txtAutoSearchE.Text + "%';";
            this.PopulateGridView(sql);
        }

        private void btnClearE_Click(object sender, EventArgs e)
        {
            txtidE.Clear();
            txtNameE.Clear();
            txtPE.Clear();
            txtSalaryE.Clear();
            txtDes.Clear();
            txtBloodE.Clear();
           

        }

        private void btnLogoutE_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBackE_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Visible = true;
            this.Visible = false;

        }

        

    }
}

