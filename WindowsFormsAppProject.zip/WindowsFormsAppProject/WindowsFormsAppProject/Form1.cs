﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsAppProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            string sql1 = @"select * from TManageE where id = '1' or password = '123';";
            DataAccess da1 = new DataAccess();
            DataSet ds1 = da1.ExecuteQuery(sql1);
            SqlConnection sqlcon1 = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=True;User ID=sa;Password=P@$$w0rd");
            if (this.txtid.Text == ds1.Tables[0].Rows[0][0].ToString() && this.txtPass.Text == ds1.Tables[0].Rows[0][2].ToString())
            {


                Manager m = new Manager();

                m.Visible = true;
                
                this.Visible = false;
            }


            else
            {
                try
                {
                    string sql = @"select *from TManageE  where id='" + this.txtid.Text + @"' and password='" + this.txtPass.Text + @"';";

                    DataAccess da = new DataAccess();
                    DataSet ds = da.ExecuteQuery(sql);

                    SqlConnection sqlcon = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=True;User ID=sa;Password=P@$$w0rd");




                    if (ds.Tables[0].Rows.Count == 1)
                    {
                        Employee e1 = new Employee();
                        e1.Visible = true;

                        this.Visible = false;
                            }

                    else
                    { MessageBox.Show("Invalid1"); }

                }

                catch (Exception exc)
                {
                    MessageBox.Show("INvalid" + exc);
                }
            }
        }

        private void lbl_Id_Click(object sender, EventArgs e)
        {

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
    

