﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppProject
{
    class DeelegateCls
    {
        delegate void del(string mystring);
        public void showmsg()
        {
            del d1 = new del(msg2);
            d1 += msg2;
            d1("Accepted");
       
        }
        void msg1(string msg)
        {
            MessageBox.Show(msg);
        }
        void msg2 (string a )
        {
            MessageBox.Show( a,"Notification");
        }

    }
}
