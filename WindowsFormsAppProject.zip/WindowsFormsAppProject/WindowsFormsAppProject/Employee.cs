﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsAppProject
{
    public partial class Employee : Form
    {
        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }
        public Employee()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateGridView();
            this.TotalGridView();

        }
        Double Amount = 0;
        public void PopulateGridView(string sql = "select * from FOODdetail;")
        {
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dgvMain.AutoGenerateColumns = false;
            this.dgvMain.DataSource = this.Ds.Tables[0];
        }
        public void TotalGridView(string sql = "select * from TableOrder;")
        {
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dGV1.AutoGenerateColumns = false;
            this.dGV1.DataSource = this.Ds.Tables[0];
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            radioButton1.ForeColor = System.Drawing.Color.Green;
            radioButton2.ForeColor = System.Drawing.Color.Red;


            cmb_items.Items.Clear();
            cmb_items.Items.Add("Muffin");
            cmb_items.Items.Add("Hotbrown");
            cmb_items.Items.Add("Custard");



        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            radioButton1.ForeColor = System.Drawing.Color.Red;
            radioButton2.ForeColor = System.Drawing.Color.Green;


            cmb_items.Items.Clear();
            cmb_items.Items.Add("Burger");
            cmb_items.Items.Add("Pizza");
            cmb_items.Items.Add("Nachoes");
        }

        private void cbm_Price_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "select *from FOODTable where price='" + this.cbm_Price.Text + "' and itemname='" + this.cmb_items.Text + "';";
            SqlConnection sqlcn = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=False;User ID=sa;Password=P@$$w0rd");
            sqlcn.Open();
            SqlCommand sqlcm = new SqlCommand(sql, sqlcn);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcm);
            DataSet ds2 = new DataSet();
            sda.Fill(ds2);
            sqlcn.Close();
            if (ds2.Tables[0].Rows.Count == 1)
            { }
            else
            {
                MessageBox.Show("Give right price!");
            }


        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            string sql = "select *from FOODTable where price='" + this.cbm_Price.Text + "' and itemname='" + this.cmb_items.Text + "';";
            SqlConnection sqlcn = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=False;User ID=sa;Password=P@$$w0rd");
            sqlcn.Open();
            SqlCommand sqlcm = new SqlCommand(sql, sqlcn);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcm);
            DataSet ds2 = new DataSet();
            sda.Fill(ds2);
            sqlcn.Close();
            if (ds2.Tables[0].Rows.Count == 1)
            {
                try
                {
                    txt_total.Text = (Convert.ToInt16(cbm_Price.Text) * Convert.ToInt16(txt_qty.Text)).ToString();
                }
                catch
                { MessageBox.Show("YOU ADDED ONE!"); }



            }
            else
            {
                MessageBox.Show("GIVE RIGHT PRICE!");
            }



        }

        private void dgvMain_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            this.cmb_items.Text = this.dgvMain.CurrentRow.Cells["itemname"].Value.ToString();
            this.cbm_Price.Text = this.dgvMain.CurrentRow.Cells["price"].Value.ToString();
            this.txt_qty.Text = this.dgvMain.CurrentRow.Cells["Quantity"].Value.ToString();
            this.txt_total.Text = this.dgvMain.CurrentRow.Cells["total"].Value.ToString();
        }


        private void dGV1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            this.txtNtotal.Text = this.dgvMain.CurrentRow.Cells["NetTotal"].Value.ToString();
            this.dateTimePicker2.Text = this.dgvMain.CurrentRow.Cells["OrderDate"].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {


                string sql = @"insert into FOODdetail (itemname,price,Quantity,total)
                values ('" + this.cmb_items.Text + "', '" + this.cbm_Price.Text + "', '" + this.txt_qty.Text + "', '" + this.txt_total.Text + "');";

                SqlConnection sqlc = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=False;User ID=sa;Password=P@$$w0rd");
                sqlc.Open();
                SqlCommand sqlcm = new SqlCommand(sql, sqlc);
                SqlDataAdapter sda = new SqlDataAdapter(sqlcm);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                sqlc.Close();
                MessageBox.Show("saved!");
                this.PopulateGridView();
                txt_qty.Clear();
                txt_total.Clear();


            }
            catch
            {
                MessageBox.Show("ERROR INSERT");

            }


        }

        private void btnDlt_Click(object sender, EventArgs e)
        {
            string id = this.dgvMain.CurrentRow.Cells["id"].Value.ToString();
            string sql = "delete from FOODdetail where id = '" + id + "';";
            try
            {
                this.Da.ExecuteUpdateQuery(sql);
                MessageBox.Show("Deletion Done.");
                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error DELETE " + exc.Message);
            }

        }

        private void btnFBiling_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvMain.Rows.Count; i++)
            {

                Amount += Convert.ToDouble(dgvMain.Rows[i].Cells["total"].Value.ToString());
               

            }
            txtNtotal.Text = Amount.ToString();
            string sql = @"select *from FOODdetail  delete from FOODdetail ;";
            try
            {
                this.Da.ExecuteUpdateQuery(sql);

                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error DELETE " + exc.Message);
            }



        }

        private void btnConfrm_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = @"insert into TableOrder (NetTotal,OrderDate)
                values ('" + this.txtNtotal.Text + "', '" + this.dateTimePicker2.Text + "');";

                SqlConnection sqlc = new SqlConnection(@"Data Source=USER\SQLEXPRESS;initial catalog=PROJECTDB;Integrated Security=False;User ID=sa;Password=P@$$w0rd");
                sqlc.Open();
                SqlCommand sqlcm = new SqlCommand(sql, sqlc);
                SqlDataAdapter sda = new SqlDataAdapter(sqlcm);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                sqlc.Close();
                MessageBox.Show("saved!");
                this.TotalGridView();
                txtNtotal.Clear();

            }

            catch
            { }

        }

       

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 f = new Form1();
            f.Visible = true;

        }

        private void btnDltOrder_Click(object sender, EventArgs e)
        {
            string OrderId = this.dGV1.CurrentRow.Cells["OrderId"].Value.ToString();
            string sql = "delete from TableOrder where OrderId = '" + OrderId + "';";
            try
            {
                this.Da.ExecuteUpdateQuery(sql);
                MessageBox.Show("Deletion Done.");
                this.TotalGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error DELETE " + exc.Message);
            }
        }


        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtNtotal.Clear();
            txt_qty.Clear();
            txt_total.Clear();



        }
    }
}

