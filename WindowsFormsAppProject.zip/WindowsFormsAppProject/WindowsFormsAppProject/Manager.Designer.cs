﻿namespace WindowsFormsAppProject
{
    partial class Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpE = new System.Windows.Forms.DateTimePicker();
            this.labelBloodE = new System.Windows.Forms.Label();
            this.btnLogoutE = new System.Windows.Forms.Button();
            this.btnBackE = new System.Windows.Forms.Button();
            this.txtAutoSearchE = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClearE = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.txtidE = new System.Windows.Forms.TextBox();
            this.txtSalaryE = new System.Windows.Forms.TextBox();
            this.txtBloodE = new System.Windows.Forms.TextBox();
            this.txtNameE = new System.Windows.Forms.TextBox();
            this.labelDateE = new System.Windows.Forms.Label();
            this.labelBlood = new System.Windows.Forms.Label();
            this.labelSalary = new System.Windows.Forms.Label();
            this.labelidE = new System.Windows.Forms.Label();
            this.labelNameE = new System.Windows.Forms.Label();
            this.dgvMain = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bloodgroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.joindate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPE = new System.Windows.Forms.TextBox();
            this.lblDes = new System.Windows.Forms.Label();
            this.txtDes = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpE
            // 
            this.dtpE.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpE.CustomFormat = "yyyy-mm-dd";
            this.dtpE.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpE.Location = new System.Drawing.Point(129, 271);
            this.dtpE.Name = "dtpE";
            this.dtpE.Size = new System.Drawing.Size(200, 20);
            this.dtpE.TabIndex = 39;
            // 
            // labelBloodE
            // 
            this.labelBloodE.AutoSize = true;
            this.labelBloodE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBloodE.Location = new System.Drawing.Point(12, 191);
            this.labelBloodE.Name = "labelBloodE";
            this.labelBloodE.Size = new System.Drawing.Size(105, 20);
            this.labelBloodE.TabIndex = 38;
            this.labelBloodE.Text = "BloodGroup";
            // 
            // btnLogoutE
            // 
            this.btnLogoutE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutE.Location = new System.Drawing.Point(209, 473);
            this.btnLogoutE.Name = "btnLogoutE";
            this.btnLogoutE.Size = new System.Drawing.Size(87, 39);
            this.btnLogoutE.TabIndex = 37;
            this.btnLogoutE.Text = "Logout";
            this.btnLogoutE.UseVisualStyleBackColor = true;
            this.btnLogoutE.Click += new System.EventHandler(this.btnLogoutE_Click);
            // 
            // btnBackE
            // 
            this.btnBackE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackE.Location = new System.Drawing.Point(10, 473);
            this.btnBackE.Name = "btnBackE";
            this.btnBackE.Size = new System.Drawing.Size(104, 39);
            this.btnBackE.TabIndex = 36;
            this.btnBackE.Text = "Back";
            this.btnBackE.UseVisualStyleBackColor = true;
            this.btnBackE.Click += new System.EventHandler(this.btnBackE_Click);
            // 
            // txtAutoSearchE
            // 
            this.txtAutoSearchE.Location = new System.Drawing.Point(221, 384);
            this.txtAutoSearchE.Name = "txtAutoSearchE";
            this.txtAutoSearchE.Size = new System.Drawing.Size(100, 20);
            this.txtAutoSearchE.TabIndex = 35;
            this.txtAutoSearchE.TextChanged += new System.EventHandler(this.txtAutoSearchE_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(221, 427);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 34;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClearE
            // 
            this.btnClearE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearE.Location = new System.Drawing.Point(22, 427);
            this.btnClearE.Name = "btnClearE";
            this.btnClearE.Size = new System.Drawing.Size(75, 23);
            this.btnClearE.TabIndex = 33;
            this.btnClearE.Text = "Clear";
            this.btnClearE.UseVisualStyleBackColor = true;
            this.btnClearE.Click += new System.EventHandler(this.btnClearE_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(113, 384);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 32;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnInsert
            // 
            this.btnInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Location = new System.Drawing.Point(113, 355);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(75, 23);
            this.btnInsert.TabIndex = 31;
            this.btnInsert.Text = "Save";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // txtidE
            // 
            this.txtidE.Location = new System.Drawing.Point(129, 70);
            this.txtidE.Name = "txtidE";
            this.txtidE.Size = new System.Drawing.Size(200, 20);
            this.txtidE.TabIndex = 29;
            // 
            // txtSalaryE
            // 
            this.txtSalaryE.Location = new System.Drawing.Point(129, 151);
            this.txtSalaryE.Name = "txtSalaryE";
            this.txtSalaryE.Size = new System.Drawing.Size(200, 20);
            this.txtSalaryE.TabIndex = 28;
            // 
            // txtBloodE
            // 
            this.txtBloodE.Location = new System.Drawing.Point(129, 193);
            this.txtBloodE.Name = "txtBloodE";
            this.txtBloodE.Size = new System.Drawing.Size(200, 20);
            this.txtBloodE.TabIndex = 27;
            // 
            // txtNameE
            // 
            this.txtNameE.Location = new System.Drawing.Point(129, 21);
            this.txtNameE.Name = "txtNameE";
            this.txtNameE.Size = new System.Drawing.Size(200, 20);
            this.txtNameE.TabIndex = 26;
            this.txtNameE.TextChanged += new System.EventHandler(this.txtNameE_TextChanged);
            // 
            // labelDateE
            // 
            this.labelDateE.AutoSize = true;
            this.labelDateE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDateE.Location = new System.Drawing.Point(6, 271);
            this.labelDateE.Name = "labelDateE";
            this.labelDateE.Size = new System.Drawing.Size(105, 20);
            this.labelDateE.TabIndex = 25;
            this.labelDateE.Text = "JoiningDate";
            // 
            // labelBlood
            // 
            this.labelBlood.AutoSize = true;
            this.labelBlood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBlood.Location = new System.Drawing.Point(65, 171);
            this.labelBlood.Name = "labelBlood";
            this.labelBlood.Size = new System.Drawing.Size(0, 20);
            this.labelBlood.TabIndex = 24;
            // 
            // labelSalary
            // 
            this.labelSalary.AutoSize = true;
            this.labelSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalary.Location = new System.Drawing.Point(14, 151);
            this.labelSalary.Name = "labelSalary";
            this.labelSalary.Size = new System.Drawing.Size(59, 20);
            this.labelSalary.TabIndex = 23;
            this.labelSalary.Text = "Salary";
            // 
            // labelidE
            // 
            this.labelidE.AutoSize = true;
            this.labelidE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelidE.Location = new System.Drawing.Point(18, 70);
            this.labelidE.Name = "labelidE";
            this.labelidE.Size = new System.Drawing.Size(28, 20);
            this.labelidE.TabIndex = 22;
            this.labelidE.Text = "ID";
            // 
            // labelNameE
            // 
            this.labelNameE.AutoSize = true;
            this.labelNameE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNameE.Location = new System.Drawing.Point(18, 21);
            this.labelNameE.Name = "labelNameE";
            this.labelNameE.Size = new System.Drawing.Size(55, 20);
            this.labelNameE.TabIndex = 21;
            this.labelNameE.Text = "Name";
            // 
            // dgvMain
            // 
            this.dgvMain.AllowUserToAddRows = false;
            this.dgvMain.AllowUserToDeleteRows = false;
            this.dgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.name,
            this.password,
            this.salary,
            this.bloodgroup,
            this.designation,
            this.joindate});
            this.dgvMain.Location = new System.Drawing.Point(335, 6);
            this.dgvMain.Name = "dgvMain";
            this.dgvMain.ReadOnly = true;
            this.dgvMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMain.Size = new System.Drawing.Size(724, 506);
            this.dgvMain.TabIndex = 40;
            this.dgvMain.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMain_CellContentDoubleClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // password
            // 
            this.password.DataPropertyName = "password";
            this.password.HeaderText = "password";
            this.password.Name = "password";
            this.password.ReadOnly = true;
            // 
            // salary
            // 
            this.salary.DataPropertyName = "salary";
            this.salary.HeaderText = "salary";
            this.salary.Name = "salary";
            this.salary.ReadOnly = true;
            // 
            // bloodgroup
            // 
            this.bloodgroup.DataPropertyName = "bloodgroup";
            this.bloodgroup.HeaderText = "bloodgroup";
            this.bloodgroup.Name = "bloodgroup";
            this.bloodgroup.ReadOnly = true;
            // 
            // designation
            // 
            this.designation.DataPropertyName = "designation";
            this.designation.HeaderText = "designation";
            this.designation.Name = "designation";
            this.designation.ReadOnly = true;
            // 
            // joindate
            // 
            this.joindate.DataPropertyName = "joindate";
            this.joindate.HeaderText = "joindate";
            this.joindate.Name = "joindate";
            this.joindate.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(381, 394);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 41;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 24);
            this.label2.TabIndex = 42;
            this.label2.Text = "Password";
            // 
            // txtPE
            // 
            this.txtPE.Location = new System.Drawing.Point(129, 109);
            this.txtPE.Name = "txtPE";
            this.txtPE.Size = new System.Drawing.Size(200, 20);
            this.txtPE.TabIndex = 43;
            // 
            // lblDes
            // 
            this.lblDes.AutoSize = true;
            this.lblDes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDes.Location = new System.Drawing.Point(6, 228);
            this.lblDes.Name = "lblDes";
            this.lblDes.Size = new System.Drawing.Size(120, 24);
            this.lblDes.TabIndex = 44;
            this.lblDes.Text = "Designation";
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(129, 233);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(200, 20);
            this.txtDes.TabIndex = 45;
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(1071, 524);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.lblDes);
            this.Controls.Add(this.txtPE);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvMain);
            this.Controls.Add(this.dtpE);
            this.Controls.Add(this.labelBloodE);
            this.Controls.Add(this.btnLogoutE);
            this.Controls.Add(this.btnBackE);
            this.Controls.Add(this.txtAutoSearchE);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClearE);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.txtidE);
            this.Controls.Add(this.txtSalaryE);
            this.Controls.Add(this.txtBloodE);
            this.Controls.Add(this.txtNameE);
            this.Controls.Add(this.labelDateE);
            this.Controls.Add(this.labelBlood);
            this.Controls.Add(this.labelSalary);
            this.Controls.Add(this.labelidE);
            this.Controls.Add(this.labelNameE);
            this.Name = "Manager";
            this.Text = "Manager";
            this.Load += new System.EventHandler(this.Manager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpE;
        private System.Windows.Forms.Label labelBloodE;
        private System.Windows.Forms.Button btnLogoutE;
        private System.Windows.Forms.Button btnBackE;
        private System.Windows.Forms.TextBox txtAutoSearchE;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClearE;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.TextBox txtidE;
        private System.Windows.Forms.TextBox txtSalaryE;
        private System.Windows.Forms.TextBox txtBloodE;
        private System.Windows.Forms.TextBox txtNameE;
        private System.Windows.Forms.Label labelDateE;
        private System.Windows.Forms.Label labelBlood;
        private System.Windows.Forms.Label labelSalary;
        private System.Windows.Forms.Label labelidE;
        private System.Windows.Forms.Label labelNameE;
        private System.Windows.Forms.DataGridView dgvMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPE;
        private System.Windows.Forms.Label lblDes;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn password;
        private System.Windows.Forms.DataGridViewTextBoxColumn salary;
        private System.Windows.Forms.DataGridViewTextBoxColumn bloodgroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn designation;
        private System.Windows.Forms.DataGridViewTextBoxColumn joindate;
    }
}